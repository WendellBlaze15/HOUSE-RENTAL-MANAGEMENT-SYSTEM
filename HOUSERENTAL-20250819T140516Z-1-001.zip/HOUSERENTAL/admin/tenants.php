<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $stmt = $pdo->prepare("INSERT INTO tenants (house_id, user_id, first_name, last_name, email, phone, move_in_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_POST['house_id'],
                    !empty($_POST['user_id']) ? $_POST['user_id'] : null,
                    $_POST['first_name'],
                    $_POST['last_name'],
                    $_POST['email'],
                    $_POST['phone'],
                    $_POST['move_in_date']
                ]);
                $id = $pdo->lastInsertId();
                $log = $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, 'add', 'tenants', ?, ?)");
                $log->execute([$_SESSION['user_id'], $id, json_encode($_POST)]);
                // Update house status to occupied
                $stmt = $pdo->prepare("UPDATE houses SET status = 'occupied' WHERE id = ?");
                $stmt->execute([$_POST['house_id']]);
                break;
            case 'edit':
                $stmt = $pdo->prepare("UPDATE tenants SET house_id = ?, user_id = ?, first_name = ?, last_name = ?, email = ?, phone = ?, move_in_date = ? WHERE id = ?");
                $stmt->execute([
                    $_POST['house_id'],
                    !empty($_POST['user_id']) ? $_POST['user_id'] : null,
                    $_POST['first_name'],
                    $_POST['last_name'],
                    $_POST['email'],
                    $_POST['phone'],
                    $_POST['move_in_date'],
                    $_POST['id']
                ]);
                $log = $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, 'edit', 'tenants', ?, ?)");
                $log->execute([$_SESSION['user_id'], $_POST['id'], json_encode($_POST)]);
                break;
            case 'delete':
                // Get the house_id before deleting the tenant
                $stmt = $pdo->prepare("SELECT house_id FROM tenants WHERE id = ?");
                $stmt->execute([$_POST['id']]);
                $house_id = $stmt->fetch()['house_id'];
                
                // Delete the tenant
                $stmt = $pdo->prepare("DELETE FROM tenants WHERE id = ?");
                $stmt->execute([$_POST['id']]);
                $log = $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, 'delete', 'tenants', ?, ?)");
                $log->execute([$_SESSION['user_id'], $_POST['id'], json_encode($_POST)]);
                
                // Update house status to available
                $stmt = $pdo->prepare("UPDATE houses SET status = 'available' WHERE id = ?");
                $stmt->execute([$house_id]);
                break;
        }
        header("Location: tenants.php");
        exit();
    }
}

// Get all tenants with their house information
$stmt = $pdo->query("
    SELECT t.*, h.house_number, h.monthly_rent, ht.type_name
    FROM tenants t
    JOIN houses h ON t.house_id = h.id
    JOIN house_types ht ON h.house_type_id = ht.id
    ORDER BY t.last_name, t.first_name
");
$tenants = $stmt->fetchAll();

// Get all houses for the dropdown (not just available)
$stmt = $pdo->query("
    SELECT h.*, ht.type_name 
    FROM houses h 
    JOIN house_types ht ON h.house_type_id = ht.id 
    ORDER BY h.house_number
");
$all_houses = $stmt->fetchAll();

// Get all users for the dropdown
$users = $pdo->query("SELECT id, username FROM users WHERE role = 'user' ORDER BY username")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenants - Cruzat House Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
            color: white;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
        }
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.8rem 1rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .btn-action {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
        }
        .modal-content {
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="mb-4">Cruzat House Rental</h3>
        <nav class="nav flex-column">
            <a class="nav-link" href="dashboard.php">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="house_types.php">
                <i class="fas fa-building me-2"></i> House Types
            </a>
            <a class="nav-link" href="houses.php">
                <i class="fas fa-house me-2"></i> Houses
            </a>
            <a class="nav-link active" href="tenants.php">
                <i class="fas fa-users me-2"></i> Tenants
            </a>
            <a class="nav-link" href="payments.php">
                <i class="fas fa-money-bill me-2"></i> Payments
            </a>
            <a class="nav-link" href="reports.php">
                <i class="fas fa-chart-bar me-2"></i> Reports
            </a>
            <a class="nav-link" href="users.php">
                <i class="fas fa-user-cog me-2"></i> Users
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Tenants</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTenantModal">
                <i class="fas fa-plus me-2"></i>Add Tenant
            </button>
        </div>

        <div class="row">
            <?php foreach ($tenants as $tenant): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name']); ?></h5>
                        <p class="card-text text-muted mb-2">
                            <i class="fas fa-house me-2"></i><?php echo htmlspecialchars($tenant['house_number']); ?> (<?php echo htmlspecialchars($tenant['type_name']); ?>)
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-money-bill me-2"></i>₱<?php echo number_format($tenant['monthly_rent'], 2); ?> / month
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-envelope me-2"></i><?php echo htmlspecialchars($tenant['email']); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-phone me-2"></i><?php echo htmlspecialchars($tenant['phone']); ?>
                        </p>
                        <p class="card-text mb-3">
                            <i class="fas fa-calendar me-2"></i>Move-in: <?php echo date('M d, Y', strtotime($tenant['move_in_date'])); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-user me-2"></i><?php echo $tenant['user_id'] ? 'User: ' . htmlspecialchars($tenant['user_id']) : 'No user linked'; ?>
                        </p>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-sm btn-warning me-2" onclick="editTenant(<?php echo htmlspecialchars(json_encode($tenant)); ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <!-- Delete button removed/disabled -->
                            <!-- <button class="btn btn-sm btn-danger" onclick="deleteTenant(<?php echo $tenant['id']; ?>)"><i class="fas fa-trash"></i></button> -->
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Add Tenant Modal -->
    <div class="modal fade" id="addTenantModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Tenant</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label class="form-label">House</label>
                            <select class="form-select" name="house_id" required>
                                <option value="">Select House</option>
                                <?php foreach ($all_houses as $house): ?>
                                <option value="<?php echo $house['id']; ?>"><?php echo htmlspecialchars($house['house_number'] . ' (' . $house['type_name'] . ') - ₱' . number_format($house['monthly_rent'], 2)); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="first_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="last_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" class="form-control" name="phone">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Move-in Date</label>
                            <input type="date" class="form-control" name="move_in_date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">User Account (optional)</label>
                            <select class="form-select" name="user_id">
                                <option value="">No user linked</option>
                                <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Tenant</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Tenant Modal -->
    <div class="modal fade" id="editTenantModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Tenant</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="mb-3">
                            <label class="form-label">House</label>
                            <select class="form-select" name="house_id" id="edit_house_id" required>
                                <?php foreach ($all_houses as $house): ?>
                                <option value="<?php echo $house['id']; ?>"> <?php echo htmlspecialchars($house['house_number'] . ' (' . $house['type_name'] . ') - ₱' . number_format($house['monthly_rent'], 2)); ?> </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="first_name" id="edit_first_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="last_name" id="edit_last_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="edit_email">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" class="form-control" name="phone" id="edit_phone">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Move-in Date</label>
                            <input type="date" class="form-control" name="move_in_date" id="edit_move_in_date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">User Account (optional)</label>
                            <select class="form-select" name="user_id" id="edit_user_id">
                                <option value="">No user linked</option>
                                <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editTenant(tenant) {
            document.getElementById('edit_id').value = tenant.id;
            document.getElementById('edit_house_id').value = tenant.house_id;
            document.getElementById('edit_first_name').value = tenant.first_name;
            document.getElementById('edit_last_name').value = tenant.last_name;
            document.getElementById('edit_email').value = tenant.email;
            document.getElementById('edit_phone').value = tenant.phone;
            document.getElementById('edit_move_in_date').value = tenant.move_in_date;
            document.getElementById('edit_user_id').value = tenant.user_id;
            new bootstrap.Modal(document.getElementById('editTenantModal')).show();
        }
    </script>
</body>
</html> 