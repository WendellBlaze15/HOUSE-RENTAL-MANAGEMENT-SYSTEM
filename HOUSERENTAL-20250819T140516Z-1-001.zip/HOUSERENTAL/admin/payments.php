<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Fix payment_month format
        $payment_month = $_POST['payment_month'];
        if (strlen($payment_month) == 7) { // e.g., '2025-05'
            $payment_month .= '-01';
        }
        if ($_POST['action'] === 'add') {
            // Prevent overpayment
            $tenant_id = $_POST['tenant_id'];
            $amount = floatval($_POST['amount']);
            $stmt = $pdo->prepare("SELECT h.monthly_rent FROM tenants t JOIN houses h ON t.house_id = h.id WHERE t.id = ?");
            $stmt->execute([$tenant_id]);
            $monthly_rent = $stmt->fetchColumn();
            $stmt = $pdo->prepare("SELECT SUM(amount) FROM payments WHERE tenant_id = ? AND payment_month = ? AND is_deleted = 0");
            $stmt->execute([$tenant_id, $payment_month]);
            $already_paid = floatval($stmt->fetchColumn());
            $remaining = $monthly_rent - $already_paid;
            if ($amount > $remaining) {
                echo '<div class="alert alert-danger">Bayad mo ay sobra sa natitirang balance (₱' . number_format($remaining, 2) . ').</div>';
            } else {
                $stmt = $pdo->prepare("INSERT INTO payments (tenant_id, amount, payment_date, payment_month, payment_type, status, remarks) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $status = ($amount + $already_paid) >= $monthly_rent ? 'paid' : 'pending';
                $stmt->execute([
                    $tenant_id,
                    $amount,
                    $_POST['payment_date'],
                    $payment_month,
                    $_POST['payment_type'],
                    $status,
                    isset($_POST['remarks']) ? $_POST['remarks'] : null
                ]);
                // After insert, update all payments for the month to correct status
                $stmt = $pdo->prepare("SELECT SUM(amount) FROM payments WHERE tenant_id = ? AND payment_month = ? AND is_deleted = 0");
                $stmt->execute([$tenant_id, $payment_month]);
                $total_paid = floatval($stmt->fetchColumn());
                $new_status = ($total_paid >= $monthly_rent) ? 'paid' : 'pending';
                $stmt = $pdo->prepare("UPDATE payments SET status = ? WHERE tenant_id = ? AND payment_month = ? AND is_deleted = 0");
                $stmt->execute([$new_status, $tenant_id, $payment_month]);
                header("Location: payments.php");
                exit();
            }
        } else if ($_POST['action'] === 'delete') {
            $stmt = $pdo->prepare("UPDATE payments SET is_deleted = 1 WHERE id = ?");
            $stmt->execute([$_POST['id']]);
            header("Location: payments.php");
            exit();
        }
    }
}

// Get all payments with tenant and house information
$stmt = $pdo->query("
    SELECT p.*, t.first_name, t.last_name, h.house_number, h.monthly_rent
    FROM payments p
    JOIN tenants t ON p.tenant_id = t.id
    JOIN houses h ON t.house_id = h.id
    WHERE p.is_deleted = 0
    ORDER BY p.payment_date DESC
");
$payments = $stmt->fetchAll();

// Get all tenants for the dropdown
$stmt = $pdo->query("
    SELECT t.*, h.house_number, h.monthly_rent
    FROM tenants t
    JOIN houses h ON t.house_id = h.id
    ORDER BY t.last_name, t.first_name
");
$tenants = $stmt->fetchAll();

// Add an endpoint for AJAX balance check
if (isset($_GET['get_balance']) && isset($_GET['tenant_id']) && isset($_GET['payment_month'])) {
    $tenant_id = intval($_GET['tenant_id']);
    $payment_month = $_GET['payment_month'];
    $stmt = $pdo->prepare("SELECT h.monthly_rent FROM tenants t JOIN houses h ON t.house_id = h.id WHERE t.id = ?");
    $stmt->execute([$tenant_id]);
    $monthly_rent = floatval($stmt->fetchColumn());
    $stmt = $pdo->prepare("SELECT SUM(amount) FROM payments WHERE tenant_id = ? AND payment_month = ? AND is_deleted = 0");
    $stmt->execute([$tenant_id, $payment_month]);
    $already_paid = floatval($stmt->fetchColumn());
    $balance = $monthly_rent - $already_paid;
    echo json_encode(['balance' => $balance, 'monthly_rent' => $monthly_rent, 'already_paid' => $already_paid]);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - Cruzat House Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
            color: white;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
        }
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.8rem 1rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .btn-action {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
        }
        .modal-content {
            border-radius: 15px;
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }
        .status-paid {
            background-color: #d4edda;
            color: #155724;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .payment-type-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            background-color: #e2e3e5;
            color: #383d41;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="mb-4">Cruzat House Rental</h3>
        <nav class="nav flex-column">
            <a class="nav-link" href="dashboard.php">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="house_types.php">
                <i class="fas fa-building me-2"></i> House Types
            </a>
            <a class="nav-link" href="houses.php">
                <i class="fas fa-house me-2"></i> Houses
            </a>
            <a class="nav-link" href="tenants.php">
                <i class="fas fa-users me-2"></i> Tenants
            </a>
            <a class="nav-link active" href="payments.php">
                <i class="fas fa-money-bill me-2"></i> Payments
            </a>
            <a class="nav-link" href="reports.php">
                <i class="fas fa-chart-bar me-2"></i> Reports
            </a>
            <a class="nav-link" href="users.php">
                <i class="fas fa-user-cog me-2"></i> Users
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Payments</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPaymentModal">
                <i class="fas fa-plus me-2"></i>Add Payment
            </button>
        </div>

        <div class="row">
            <?php foreach ($payments as $payment): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h5 class="card-title mb-0"><?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?></h5>
                            <span class="status-badge status-<?php echo $payment['status']; ?>">
                                <?php echo ucfirst($payment['status']); ?>
                            </span>
                        </div>
                        <p class="card-text text-muted mb-2">
                            <i class="fas fa-house me-2"></i><?php echo htmlspecialchars($payment['house_number']); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-money-bill me-2"></i>₱<?php echo number_format($payment['amount'], 2); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-calendar me-2"></i>Payment Date: <?php echo date('M d, Y', strtotime($payment['payment_date'])); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-calendar-alt me-2"></i>For Month: <?php echo date('M Y', strtotime($payment['payment_month'])); ?>
                        </p>
                        <?php if (!empty($payment['remarks'])): ?>
                        <p class="card-text text-muted mb-2"><i class="fas fa-sticky-note me-2"></i><?php echo htmlspecialchars($payment['remarks']); ?></p>
                        <?php endif; ?>
                        <p class="card-text mb-3">
                            <span class="payment-type-badge">
                                <?php echo ucfirst($payment['payment_type']); ?> Payment
                            </span>
                        </p>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-sm btn-danger" onclick="deletePayment(<?php echo $payment['id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Add Payment Modal -->
    <div class="modal fade" id="addPaymentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label class="form-label">Tenant</label>
                            <select class="form-select" name="tenant_id" id="add_tenant_id" required>
                                <option value="">Select Tenant</option>
                                <?php foreach ($tenants as $tenant): ?>
                                <option value="<?php echo $tenant['id']; ?>">
                                    <?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name'] . ' - ' . $tenant['house_number'] . ' (₱' . number_format($tenant['monthly_rent'], 2) . ')'); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="balance-info" class="mt-2 text-info"></div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Amount</label>
                            <input type="number" class="form-control" name="amount" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Date</label>
                            <input type="date" class="form-control" name="payment_date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Month</label>
                            <input type="month" class="form-control" name="payment_month" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Type</label>
                            <select class="form-select" name="payment_type" required>
                                <option value="full">Full Payment</option>
                                <option value="partial">Partial Payment</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" required>
                                <option value="paid">Paid</option>
                                <option value="pending">Pending</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Remarks (optional)</label>
                            <input type="text" class="form-control" name="remarks" maxlength="255">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add Payment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Payment Form -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="delete_id">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function deletePayment(id) {
            if (confirm('Are you sure you want to delete this payment?')) {
                document.getElementById('delete_id').value = id;
                document.getElementById('deleteForm').submit();
            }
        }

        function updateBalanceInfo() {
            var tenantId = document.getElementById('add_tenant_id').value;
            var paymentMonth = document.querySelector('input[name="payment_month"]').value;
            if (tenantId && paymentMonth) {
                fetch('payments.php?get_balance=1&tenant_id=' + tenantId + '&payment_month=' + paymentMonth)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('balance-info').innerHTML = 'Current Balance: ₱' + data.balance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    });
            } else {
                document.getElementById('balance-info').innerHTML = '';
            }
        }
        document.getElementById('add_tenant_id').addEventListener('change', updateBalanceInfo);
        document.querySelector('input[name="payment_month"]').addEventListener('change', updateBalanceInfo);
    </script>
</body>
</html> 