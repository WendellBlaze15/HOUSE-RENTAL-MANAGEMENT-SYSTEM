<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as total_houses FROM houses");
$total_houses = $stmt->fetch()['total_houses'];

$stmt = $pdo->query("SELECT COUNT(*) as total_tenants FROM tenants");
$total_tenants = $stmt->fetch()['total_tenants'];

$current_month = date('Y-m');
$stmt = $pdo->prepare("SELECT SUM(amount) as total_payments FROM payments WHERE DATE_FORMAT(payment_date, '%Y-%m') = ? AND is_deleted = 0");
$stmt->execute([$current_month]);
$total_payments = $stmt->fetch()['total_payments'] ?? 0;

// Get recent payments
$stmt = $pdo->query("
    SELECT p.*, t.first_name, t.last_name, h.house_number 
    FROM payments p 
    JOIN tenants t ON p.tenant_id = t.id 
    JOIN houses h ON t.house_id = h.id 
    WHERE p.is_deleted = 0
    ORDER BY p.payment_date DESC 
    LIMIT 5
");
$recent_payments = $stmt->fetchAll();

// Get outstanding balances
$stmt = $pdo->query("
    SELECT t.*, h.house_number, h.monthly_rent,
           (SELECT SUM(amount) FROM payments WHERE tenant_id = t.id AND DATE_FORMAT(payment_month, '%Y-%m') = DATE_FORMAT(CURRENT_DATE, '%Y-%m') AND is_deleted = 0) as current_month_payment
    FROM tenants t
    JOIN houses h ON t.house_id = h.id
    HAVING current_month_payment < h.monthly_rent OR current_month_payment IS NULL
");
$outstanding_balances = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Cruzat House Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
            color: white;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
        }
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.8rem 1rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: #667eea;
        }
        .recent-payments, .outstanding-balances {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="mb-4">Cruzat House Rental</h3>
        <nav class="nav flex-column">
            <a class="nav-link active" href="dashboard.php">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="house_types.php">
                <i class="fas fa-building me-2"></i> House Types
            </a>
            <a class="nav-link" href="houses.php">
                <i class="fas fa-house me-2"></i> Houses
            </a>
            <a class="nav-link" href="tenants.php">
                <i class="fas fa-users me-2"></i> Tenants
            </a>
            <a class="nav-link" href="payments.php">
                <i class="fas fa-money-bill me-2"></i> Payments
            </a>
            <a class="nav-link" href="reports.php">
                <i class="fas fa-chart-bar me-2"></i> Reports
            </a>
            <a class="nav-link" href="users.php">
                <i class="fas fa-user-cog me-2"></i> Users
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2 class="mb-4">Dashboard</h2>
        
        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <h3><?php echo $total_houses; ?></h3>
                    <p class="text-muted">Total Houses</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3><?php echo $total_tenants; ?></h3>
                    <p class="text-muted">Total Tenants</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <h3>₱<?php echo number_format($total_payments, 2); ?></h3>
                    <p class="text-muted">Payments This Month</p>
                </div>
            </div>
        </div>

        <!-- Recent Payments -->
        <div class="recent-payments">
            <h4 class="mb-3">Recent Payments</h4>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tenant</th>
                            <th>House</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_payments as $payment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($payment['house_number']); ?></td>
                            <td>₱<?php echo number_format($payment['amount'], 2); ?></td>
                            <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $payment['status'] == 'paid' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($payment['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Outstanding Balances -->
        <div class="outstanding-balances">
            <h4 class="mb-3">Outstanding Balances</h4>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tenant</th>
                            <th>House</th>
                            <th>Monthly Rent</th>
                            <th>Paid This Month</th>
                            <th>Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($outstanding_balances as $tenant): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($tenant['house_number']); ?></td>
                            <td>₱<?php echo number_format($tenant['monthly_rent'], 2); ?></td>
                            <td>₱<?php echo number_format($tenant['current_month_payment'] ?? 0, 2); ?></td>
                            <td>₱<?php echo number_format($tenant['monthly_rent'] - ($tenant['current_month_payment'] ?? 0), 2); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 