<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $stmt = $pdo->prepare("INSERT INTO houses (house_type_id, house_number, description, monthly_rent, status) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_POST['house_type_id'],
                    $_POST['house_number'],
                    $_POST['description'],
                    $_POST['monthly_rent'],
                    $_POST['status']
                ]);
                $id = $pdo->lastInsertId();
                $log = $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, 'add', 'houses', ?, ?)");
                $log->execute([$_SESSION['user_id'], $id, json_encode($_POST)]);
                break;
            case 'edit':
                $stmt = $pdo->prepare("UPDATE houses SET house_type_id = ?, house_number = ?, description = ?, monthly_rent = ?, status = ? WHERE id = ?");
                $stmt->execute([
                    $_POST['house_type_id'],
                    $_POST['house_number'],
                    $_POST['description'],
                    $_POST['monthly_rent'],
                    $_POST['status'],
                    $_POST['id']
                ]);
                $log = $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, 'edit', 'houses', ?, ?)");
                $log->execute([$_SESSION['user_id'], $_POST['id'], json_encode($_POST)]);
                break;
            case 'delete':
                $stmt = $pdo->prepare("DELETE FROM houses WHERE id = ?");
                $stmt->execute([$_POST['id']]);
                $log = $pdo->prepare("INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, 'delete', 'houses', ?, ?)");
                $log->execute([$_SESSION['user_id'], $_POST['id'], json_encode($_POST)]);
                break;
        }
        header("Location: houses.php");
        exit();
    }
}

// Get all houses with their types (including latest description)
$stmt = $pdo->query("
    SELECT h.*, ht.type_name, ht.description as type_description
    FROM houses h 
    JOIN house_types ht ON h.house_type_id = ht.id 
    ORDER BY h.house_number
");
$houses = $stmt->fetchAll();

// Get all house types for the dropdown
$stmt = $pdo->query("SELECT * FROM house_types ORDER BY type_name");
$house_types = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Houses - Cruzat House Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
            color: white;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
        }
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.8rem 1rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .btn-action {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
        }
        .modal-content {
            border-radius: 15px;
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }
        .status-available {
            background-color: #d4edda;
            color: #155724;
        }
        .status-occupied {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="mb-4">Cruzat House Rental</h3>
        <nav class="nav flex-column">
            <a class="nav-link" href="dashboard.php">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="house_types.php">
                <i class="fas fa-building me-2"></i> House Types
            </a>
            <a class="nav-link active" href="houses.php">
                <i class="fas fa-house me-2"></i> Houses
            </a>
            <a class="nav-link" href="tenants.php">
                <i class="fas fa-users me-2"></i> Tenants
            </a>
            <a class="nav-link" href="payments.php">
                <i class="fas fa-money-bill me-2"></i> Payments
            </a>
            <a class="nav-link" href="reports.php">
                <i class="fas fa-chart-bar me-2"></i> Reports
            </a>
            <a class="nav-link" href="users.php">
                <i class="fas fa-user-cog me-2"></i> Users
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Houses</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addHouseModal">
                <i class="fas fa-plus me-2"></i>Add House
            </button>
        </div>

        <div class="row">
            <?php foreach ($houses as $house): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <h5 class="card-title mb-0"><?php echo htmlspecialchars($house['house_number']); ?></h5>
                            <span class="status-badge status-<?php echo $house['status']; ?>">
                                <?php echo ucfirst($house['status']); ?>
                            </span>
                        </div>
                        <p class="card-text text-muted mb-2">
                            <i class="fas fa-building me-2"></i><?php echo htmlspecialchars($house['type_name']); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-info-circle me-2"></i><?php echo htmlspecialchars($house['type_description']); ?>
                        </p>
                        <p class="card-text mb-2">
                            <i class="fas fa-money-bill me-2"></i>₱<?php echo number_format($house['monthly_rent'], 2); ?> / month
                        </p>
                        <p class="card-text"><?php echo htmlspecialchars($house['description']); ?></p>
                        <div class="d-flex justify-content-end">
                            <button class="btn btn-sm btn-warning me-2" onclick="editHouse(<?php echo htmlspecialchars(json_encode($house)); ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteHouse(<?php echo $house['id']; ?>)" <?php if ($house['status'] === 'occupied') echo 'disabled title="Cannot delete: House is occupied"'; ?>>
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Add House Modal -->
    <div class="modal fade" id="addHouseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add House</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label class="form-label">House Type</label>
                            <select class="form-select" name="house_type_id" required>
                                <option value="">Select House Type</option>
                                <?php foreach ($house_types as $type): ?>
                                <option value="<?php echo $type['id']; ?>"><?php echo htmlspecialchars($type['type_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">House Number</label>
                            <input type="text" class="form-control" name="house_number" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Monthly Rent</label>
                            <input type="number" class="form-control" name="monthly_rent" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" required>
                                <option value="available">Available</option>
                                <option value="occupied">Occupied</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Add House</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit House Modal -->
    <div class="modal fade" id="editHouseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit House</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="mb-3">
                            <label class="form-label">House Type</label>
                            <select class="form-select" name="house_type_id" id="edit_house_type_id" required>
                                <?php foreach ($house_types as $type): ?>
                                <option value="<?php echo $type['id']; ?>"><?php echo htmlspecialchars($type['type_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">House Number</label>
                            <input type="text" class="form-control" name="house_number" id="edit_house_number" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Monthly Rent</label>
                            <input type="number" class="form-control" name="monthly_rent" id="edit_monthly_rent" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="edit_status" required>
                                <option value="available">Available</option>
                                <option value="occupied">Occupied</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="edit_description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete House Form -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="delete_id">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editHouse(house) {
            document.getElementById('edit_id').value = house.id;
            document.getElementById('edit_house_type_id').value = house.house_type_id;
            document.getElementById('edit_house_number').value = house.house_number;
            document.getElementById('edit_monthly_rent').value = house.monthly_rent;
            document.getElementById('edit_status').value = house.status;
            document.getElementById('edit_description').value = house.description;
            new bootstrap.Modal(document.getElementById('editHouseModal')).show();
        }

        function deleteHouse(id) {
            if (confirm('Are you sure you want to delete this house?')) {
                document.getElementById('delete_id').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
</body>
</html> 