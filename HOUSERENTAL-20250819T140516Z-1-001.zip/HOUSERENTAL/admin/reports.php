<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Get date range from query parameters or default to current month
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');

// Get total houses and occupancy rate
$stmt = $pdo->query("SELECT COUNT(*) as total_houses FROM houses");
$total_houses = $stmt->fetch()['total_houses'];

$stmt = $pdo->query("SELECT COUNT(*) as occupied_houses FROM houses WHERE status = 'occupied'");
$occupied_houses = $stmt->fetch()['occupied_houses'];
$occupancy_rate = ($total_houses > 0) ? ($occupied_houses / $total_houses) * 100 : 0;

// Get total revenue for the selected period
$stmt = $pdo->prepare("
    SELECT SUM(amount) as total_revenue 
    FROM payments 
    WHERE payment_date BETWEEN ? AND ? AND status = 'paid' AND is_deleted = 0
");
$stmt->execute([$start_date, $end_date]);
$total_revenue = $stmt->fetch()['total_revenue'] ?? 0;

// Get monthly revenue for the last 6 months
$stmt = $pdo->query("
    SELECT DATE_FORMAT(payment_date, '%Y-%m') as month, SUM(amount) as revenue
    FROM payments
    WHERE payment_date >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
    AND status = 'paid' AND is_deleted = 0
    GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
    ORDER BY month
");
$monthly_revenue = $stmt->fetchAll();

// Get house type distribution
$stmt = $pdo->query("
    SELECT ht.type_name, COUNT(h.id) as count
    FROM house_types ht
    LEFT JOIN houses h ON ht.id = h.house_type_id
    GROUP BY ht.id
");
$house_type_distribution = $stmt->fetchAll();

// Get payment status distribution
$stmt = $pdo->prepare("
    SELECT status, COUNT(*) as count
    FROM payments
    WHERE payment_date BETWEEN ? AND ? AND is_deleted = 0
    GROUP BY status
");
$stmt->execute([$start_date, $end_date]);
$payment_status = $stmt->fetchAll();

// Get top paying tenants
$stmt = $pdo->prepare("
    SELECT t.first_name, t.last_name, h.house_number, SUM(p.amount) as total_paid
    FROM tenants t
    JOIN houses h ON t.house_id = h.id
    JOIN payments p ON t.id = p.tenant_id
    WHERE p.payment_date BETWEEN ? AND ? AND p.status = 'paid' AND p.is_deleted = 0
    GROUP BY t.id
    ORDER BY total_paid DESC
    LIMIT 5
");
$stmt->execute([$start_date, $end_date]);
$top_tenants = $stmt->fetchAll();

// Get payment collection rate
$stmt = $pdo->prepare("
    SELECT 
        COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count,
        COUNT(*) as total_count
    FROM payments
    WHERE payment_date BETWEEN ? AND ? AND is_deleted = 0
");
$stmt->execute([$start_date, $end_date]);
$payment_stats = $stmt->fetch();
$collection_rate = ($payment_stats['total_count'] > 0) ? 
    ($payment_stats['paid_count'] / $payment_stats['total_count']) * 100 : 0;

// Get all tenants for the dropdown
$all_tenants = $pdo->query("SELECT t.id, t.first_name, t.last_name, h.house_number FROM tenants t JOIN houses h ON t.house_id = h.id ORDER BY t.last_name, t.first_name")->fetchAll();
$selected_tenant_id = isset($_GET['tenant_id']) ? intval($_GET['tenant_id']) : null;
$tenant_payments = [];
if ($selected_tenant_id) {
    $stmt = $pdo->prepare("SELECT * FROM payments WHERE tenant_id = ? AND is_deleted = 0 ORDER BY payment_date DESC");
    $stmt->execute([$selected_tenant_id]);
    $tenant_payments = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Cruzat House Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --sidebar-width: 250px;
        }
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
            color: white;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
        }
        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.8rem 1rem;
            border-radius: 10px;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .stat-card {
            text-align: center;
            padding: 1.5rem;
        }
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #667eea;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            color: #6c757d;
            font-size: 1.1rem;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="mb-4">Cruzat House Rental</h3>
        <nav class="nav flex-column">
            <a class="nav-link" href="dashboard.php">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="house_types.php">
                <i class="fas fa-building me-2"></i> House Types
            </a>
            <a class="nav-link" href="houses.php">
                <i class="fas fa-house me-2"></i> Houses
            </a>
            <a class="nav-link" href="tenants.php">
                <i class="fas fa-users me-2"></i> Tenants
            </a>
            <a class="nav-link" href="payments.php">
                <i class="fas fa-money-bill me-2"></i> Payments
            </a>
            <a class="nav-link active" href="reports.php">
                <i class="fas fa-chart-bar me-2"></i> Reports
            </a>
            <a class="nav-link" href="users.php">
                <i class="fas fa-user-cog me-2"></i> Users
            </a>
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-sign-out-alt me-2"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Reports</h2>
            <form class="d-flex gap-2">
                <input type="date" class="form-control" name="start_date" value="<?php echo $start_date; ?>">
                <input type="date" class="form-control" name="end_date" value="<?php echo $end_date; ?>">
                <button type="submit" class="btn btn-primary">Apply Filter</button>
            </form>
        </div>

        <!-- Statistics Cards -->
        <div class="row">
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <div class="stat-value"><?php echo $total_houses; ?></div>
                    <div class="stat-label">Total Houses</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($occupancy_rate, 1); ?>%</div>
                    <div class="stat-label">Occupancy Rate</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-value">₱<?php echo number_format($total_revenue, 2); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($collection_rate, 1); ?>%</div>
                    <div class="stat-label">Collection Rate</div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Monthly Revenue</h5>
                        <div class="chart-container">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">House Type Distribution</h5>
                        <div class="chart-container">
                            <canvas id="houseTypeChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment Status and Top Tenants -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Payment Status</h5>
                        <div class="chart-container">
                            <canvas id="paymentStatusChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Top Paying Tenants</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tenant</th>
                                        <th>House</th>
                                        <th>Total Paid</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_tenants as $tenant): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($tenant['first_name'] . ' ' . $tenant['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($tenant['house_number']); ?></td>
                                        <td>₱<?php echo number_format($tenant['total_paid'], 2); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Payment History Report -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Payment History Report</h5>
                <form method="get" class="mb-3">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-6">
                            <label class="form-label">Select Tenant</label>
                            <select class="form-select" name="tenant_id" onchange="this.form.submit()">
                                <option value="">-- Select Tenant --</option>
                                <?php foreach ($all_tenants as $t): ?>
                                <option value="<?php echo $t['id']; ?>" <?php if ($selected_tenant_id == $t['id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($t['first_name'] . ' ' . $t['last_name'] . ' - ' . $t['house_number']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </form>
                <?php if ($selected_tenant_id): ?>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="mb-0">Payment History Table</h6>
                    <button class="btn btn-secondary btn-sm" onclick="printPaymentHistory()"><i class="fas fa-print me-1"></i> Print</button>
                </div>
                <div id="payment-history-table-print">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Petsa ng Bayad</th>
                                    <th>Halaga</th>
                                    <th>Status</th>
                                    <th>Buwan</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tenant_payments as $p): ?>
                                <tr>
                                    <td><?php echo date('M d, Y', strtotime($p['payment_date'])); ?></td>
                                    <td>₱<?php echo number_format($p['amount'], 2); ?></td>
                                    <td><?php echo ucfirst($p['status']); ?></td>
                                    <td><?php echo date('M Y', strtotime($p['payment_month'])); ?></td>
                                    <td><?php echo htmlspecialchars($p['remarks']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <script>
                function printPaymentHistory() {
                    var printContents = document.getElementById('payment-history-table-print').innerHTML;
                    var originalContents = document.body.innerHTML;
                    document.body.innerHTML = '<h2>Payment History Report</h2>' + printContents;
                    window.print();
                    document.body.innerHTML = originalContents;
                    location.reload();
                }
                </script>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Monthly Revenue Chart
        new Chart(document.getElementById('revenueChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($monthly_revenue, 'month')); ?>,
                datasets: [{
                    label: 'Revenue',
                    data: <?php echo json_encode(array_column($monthly_revenue, 'revenue')); ?>,
                    borderColor: '#667eea',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        // House Type Distribution Chart
        new Chart(document.getElementById('houseTypeChart'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($house_type_distribution, 'type_name')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($house_type_distribution, 'count')); ?>,
                    backgroundColor: [
                        '#667eea',
                        '#764ba2',
                        '#4fd1c5',
                        '#48bb78',
                        '#ed8936'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        // Payment Status Chart
        new Chart(document.getElementById('paymentStatusChart'), {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_column($payment_status, 'status')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($payment_status, 'count')); ?>,
                    backgroundColor: [
                        '#48bb78',
                        '#ed8936'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html> 