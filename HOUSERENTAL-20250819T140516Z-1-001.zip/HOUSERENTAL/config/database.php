<?php
$host = 'localhost';
$dbname = 'rental_house';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Test query to verify admin user
    $stmt = $pdo->query("SELECT * FROM users WHERE username = 'admin'");
    $admin = $stmt->fetch();
    if ($admin) {
        error_log("Admin user found in database. Password: " . $admin['password']);
    } else {
        error_log("Admin user not found in database!");
    }
} catch(PDOException $e) {
    error_log("Connection failed: " . $e->getMessage());
    die("Connection failed: " . $e->getMessage());
}

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?> 