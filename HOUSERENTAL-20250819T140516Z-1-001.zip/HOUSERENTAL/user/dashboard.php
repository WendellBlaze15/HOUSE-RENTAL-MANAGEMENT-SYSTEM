<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../index.php");
    exit();
}

// Get user info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Get tenant info by user_id
$stmt = $pdo->prepare("SELECT t.*, h.house_number, h.monthly_rent, ht.type_name
    FROM tenants t
    JOIN houses h ON t.house_id = h.id
    JOIN house_types ht ON h.house_type_id = ht.id
    WHERE t.user_id = ? LIMIT 1");
$stmt->execute([$user['id']]);
$tenant = $stmt->fetch();

// Get payments (if tenant)
$payments = [];
$current_month = date('Y-m');
$current_month_paid = 0;
$balance = null;
if ($tenant) {
    $stmt = $pdo->prepare("SELECT * FROM payments WHERE tenant_id = ? AND is_deleted = 0 ORDER BY payment_date DESC");
    $stmt->execute([$tenant['id']]);
    $payments = $stmt->fetchAll();
    // Calculate current month paid and balance
    $stmt = $pdo->prepare("SELECT SUM(amount) as paid FROM payments WHERE tenant_id = ? AND is_deleted = 0 AND DATE_FORMAT(payment_month, '%Y-%m') = ?");
    $stmt->execute([$tenant['id'], $current_month]);
    $current_month_paid = $stmt->fetch()['paid'] ?? 0;
    $balance = $tenant['monthly_rent'] - $current_month_paid;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - Cruzat House Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --sidebar-width: 250px; }
        body { background-color: #f8f9fa; }
        .sidebar { position: fixed; top: 0; left: 0; height: 100vh; width: var(--sidebar-width); background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1rem; color: white; transition: all 0.3s ease; }
        .main-content { margin-left: var(--sidebar-width); padding: 2rem; }
        .nav-link { color: rgba(255,255,255,0.8); padding: 0.8rem 1rem; border-radius: 10px; margin-bottom: 0.5rem; transition: all 0.3s ease; }
        .nav-link:hover { color: white; background: rgba(255,255,255,0.1); transform: translateX(5px); }
        .nav-link.active { background: rgba(255,255,255,0.2); color: white; }
        .card { border-radius: 15px; box-shadow: 0 0 15px rgba(0,0,0,0.05); transition: all 0.3s ease; }
        .card:hover { transform: translateY(-5px); box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .table { background: white; border-radius: 10px; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="mb-4">Cruzat House Rental</h3>
        <nav class="nav flex-column">
            <a class="nav-link active" href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
            <a class="nav-link" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
        </nav>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <h2 class="mb-4">Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card p-3 mb-3">
                    <h5>My Account</h5>
                    <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                    <p><strong>Account Created:</strong> <?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
                    <?php if ($tenant): ?>
                    <p><strong>Email Address:</strong> <?php echo htmlspecialchars($tenant['email']); ?></p>
                    <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($tenant['phone']); ?></p>
                    <?php endif; ?>
                </div>
                <?php if ($tenant): ?>
                <div class="card p-3">
                    <h5>My House</h5>
                    <p><strong>House Number:</strong> <?php echo htmlspecialchars($tenant['house_number']); ?></p>
                    <p><strong>Type:</strong> <?php echo htmlspecialchars($tenant['type_name']); ?></p>
                    <p><strong>Monthly Rent:</strong> ₱<?php echo number_format($tenant['monthly_rent'], 2); ?></p>
                    <p><strong>Move-in Date:</strong> <?php echo date('M d, Y', strtotime($tenant['move_in_date'])); ?></p>
                    <p><strong>Current Month Paid:</strong> ₱<?php echo number_format($current_month_paid, 2); ?></p>
                    <p><strong>Balance:</strong> ₱<?php echo number_format($balance, 2); ?></p>
                </div>
                <?php else: ?>
                <div class="card p-3">
                    <h5>My House</h5>
                    <p class="text-muted">No house assigned yet.</p>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="card p-3">
                    <h5>My Payments</h5>
                    <?php if ($tenant && $payments): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Amount</th>
                                    <th>Payment Date</th>
                                    <th>For Month</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td>₱<?php echo number_format($payment['amount'], 2); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                    <td><?php echo date('M Y', strtotime($payment['payment_month'])); ?></td>
                                    <td><?php echo ucfirst($payment['payment_type']); ?></td>
                                    <td><?php echo ucfirst($payment['status']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p class="text-muted">No payments found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 